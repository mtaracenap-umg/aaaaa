<?php
require "conexion.php";
header("Content-Type: application/json");

$metodo = $_SERVER["REQUEST_METHOD"];
$datos = json_decode(file_get_contents("php://input"), true);

// Crear un usuario nuevo
if ($metodo === "POST") {
    $sql = $conexion->prepare("INSERT INTO usuarios (nombre, email) VALUES (?, ?)");
    $sql->bind_param("ss", $datos["nombre"], $datos["email"]);
    $sql->execute();
    echo json_encode(["ok" => true]);
    exit;
}

// Editar un usuario existente
if ($metodo === "PUT") {
    $sql = $conexion->prepare("UPDATE usuarios SET nombre = ?, email = ? WHERE id = ?");
    $sql->bind_param("ssi", $datos["nombre"], $datos["email"], $datos["id"]);
    $sql->execute();
    echo json_encode(["ok" => true]);
    exit;
}

// Eliminar un usuario
if ($metodo === "DELETE") {
    $sql = $conexion->prepare("DELETE FROM usuarios WHERE id = ?");
    $sql->bind_param("i", $datos["id"]);
    $sql->execute();
    echo json_encode(["ok" => true]);
    exit;
}

// Listar todos los usuarios (GET)
$resultado = $conexion->query("SELECT * FROM usuarios ORDER BY id DESC");
$usuarios = [];

while ($fila = $resultado->fetch_assoc()) {
    $usuarios[] = $fila;
}

echo json_encode($usuarios);
?>
