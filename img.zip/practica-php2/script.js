// Pide los usuarios y los pinta en la tabla
function cargar() {
    fetch("api.php")
        .then(res => res.json())
        .then(usuarios => {
            const tabla = document.getElementById("tabla");
            tabla.innerHTML = "";
            usuarios.forEach(u => {
                tabla.innerHTML += `
                    <tr>
                        <td>${u.id}</td>
                        <td>${u.nombre}</td>
                        <td>${u.email}</td>
                        <td>
                            <button onclick="editar(${u.id}, '${u.nombre}', '${u.email}')">Editar</button>
                            <button onclick="eliminar(${u.id})">Eliminar</button>
                        </td>
                    </tr>`;
            });
        });
}

// Guarda: crea uno nuevo o actualiza si hay un id cargado
function guardar() {
    const id = document.getElementById("id").value;
    const nombre = document.getElementById("nombre").value;
    const email = document.getElementById("email").value;

    if (!nombre || !email) return;

    const metodo = id ? "PUT" : "POST";

    fetch("api.php", {
        method: metodo,
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ id, nombre, email })
    })
    .then(() => {
        limpiar();
        cargar();
    });
}

// Pone los datos de una fila en el formulario para editarla
function editar(id, nombre, email) {
    document.getElementById("id").value = id;
    document.getElementById("nombre").value = nombre;
    document.getElementById("email").value = email;
}

// Elimina un usuario
function eliminar(id) {
    if (!confirm("¿Eliminar este usuario?")) return;

    fetch("api.php", {
        method: "DELETE",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ id })
    })
    .then(() => cargar());
}

// Vacía el formulario
function limpiar() {
    document.getElementById("id").value = "";
    document.getElementById("nombre").value = "";
    document.getElementById("email").value = "";
}

cargar();
