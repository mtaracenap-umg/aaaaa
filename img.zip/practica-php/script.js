// Pide los usuarios al servidor y los muestra
function cargar() {
    fetch("api.php")
        .then(res => res.json())
        .then(usuarios => {
            const lista = document.getElementById("lista");
            lista.innerHTML = "";
            usuarios.forEach(u => {
                lista.innerHTML += `<li>${u.nombre} — ${u.email}</li>`;
            });
        });
}

// Envía un usuario nuevo al servidor
function guardar() {
    const nombre = document.getElementById("nombre").value;
    const email = document.getElementById("email").value;

    if (!nombre || !email) return;

    fetch("api.php", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ nombre, email })
    })
    .then(() => {
        document.getElementById("nombre").value = "";
        document.getElementById("email").value = "";
        cargar();
    });
}

cargar();
