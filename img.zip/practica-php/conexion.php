<?php
// Cambia estos datos por los de tu servidor
$host = "localhost";
$usuario = "root";
$clave = "";
$base = "mi_app";

$conexion = new mysqli($host, $usuario, $clave, $base);

if ($conexion->connect_error) {
    die("Error de conexión: " . $conexion->connect_error);
}
?>
