<?php
require "conexion.php";
header("Content-Type: application/json");

// Si llega un POST, guardamos un usuario nuevo
if ($_SERVER["REQUEST_METHOD"] === "POST") {
    $datos = json_decode(file_get_contents("php://input"), true);

    $sql = $conexion->prepare("INSERT INTO usuarios (nombre, email) VALUES (?, ?)");
    $sql->bind_param("ss", $datos["nombre"], $datos["email"]);
    $sql->execute();

    echo json_encode(["ok" => true]);
    exit;
}

// Si es GET, devolvemos todos los usuarios
$resultado = $conexion->query("SELECT * FROM usuarios ORDER BY id DESC");
$usuarios = [];

while ($fila = $resultado->fetch_assoc()) {
    $usuarios[] = $fila;
}

echo json_encode($usuarios);
?>
